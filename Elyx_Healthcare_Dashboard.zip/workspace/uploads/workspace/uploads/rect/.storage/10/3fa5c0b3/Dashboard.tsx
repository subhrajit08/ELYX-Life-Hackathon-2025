import { useState, useMemo } from 'react';
import { UserSelector } from '../components/UserSelector';
import { MetricsCard } from '../components/MetricsCard';
import { HealthChart } from '../components/HealthChart';
import { ActivityList } from '../components/ActivityList';
import { mockUsers, mockActivities } from '../data/mockData';
import { Activity, ChartData } from '../types/health';
import { Heart, Footprints, Moon, Zap, Gauge, User } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

export default function Dashboard() {
  const [selectedUserId, setSelectedUserId] = useState<string>(mockUsers[0].id);

  const selectedUser = useMemo(() => 
    mockUsers.find(u => u.id === selectedUserId), 
    [selectedUserId]
  );

  const userActivities = useMemo(() => 
    mockActivities.filter(a => a.userId === selectedUserId), 
    [selectedUserId]
  );

  const getLatestMetric = (type: Activity['type']) => {
    const activities = userActivities
      .filter(a => a.type === type)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    
    return activities[0];
  };

  const getChartData = (type: Activity['type']): ChartData[] => {
    return userActivities
      .filter(a => a.type === type)
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
      .map(a => ({
        date: a.timestamp,
        value: Math.round(a.value * 100) / 100
      }));
  };

  const getTrend = (type: Activity['type']) => {
    const data = getChartData(type);
    if (data.length < 2) return { trend: 'stable' as const, value: '0%' };
    
    const latest = data[data.length - 1].value;
    const previous = data[data.length - 2].value;
    const change = ((latest - previous) / previous) * 100;
    
    return {
      trend: change > 5 ? 'up' as const : change < -5 ? 'down' as const : 'stable' as const,
      value: `${Math.abs(Math.round(change))}%`
    };
  };

  const latestSteps = getLatestMetric('steps');
  const latestHeartRate = getLatestMetric('heartRate');
  const latestSleep = getLatestMetric('sleep');
  const latestCalories = getLatestMetric('calories');
  const latestBP = getLatestMetric('bloodPressure');

  const stepsTrend = getTrend('steps');
  const heartRateTrend = getTrend('heartRate');
  const sleepTrend = getTrend('sleep');
  const caloriesTrend = getTrend('calories');

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Healthcare Dashboard</h1>
            <p className="text-muted-foreground">Monitor patient health metrics and activities</p>
          </div>
          <div className="w-full md:w-80">
            <UserSelector
              users={mockUsers}
              selectedUserId={selectedUserId}
              onUserSelect={setSelectedUserId}
            />
          </div>
        </div>

        {/* Patient Info Card */}
        {selectedUser && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-3">
                <User className="h-5 w-5" />
                <span>Patient Information</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-4">
                <Avatar className="h-16 w-16">
                  <AvatarImage src={selectedUser.avatar} />
                  <AvatarFallback className="text-lg">
                    {selectedUser.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="text-xl font-semibold">{selectedUser.name}</h3>
                  <p className="text-muted-foreground">Age: {selectedUser.age}</p>
                  <p className="text-muted-foreground">{selectedUser.email}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <MetricsCard
            title="Daily Steps"
            value={latestSteps?.value.toLocaleString() || '0'}
            unit="steps"
            trend={stepsTrend.trend}
            trendValue={stepsTrend.value}
            icon={<Footprints className="h-4 w-4" />}
            color="bg-blue-500"
          />
          <MetricsCard
            title="Heart Rate"
            value={latestHeartRate?.value.toString() || '0'}
            unit="bpm"
            trend={heartRateTrend.trend}
            trendValue={heartRateTrend.value}
            icon={<Heart className="h-4 w-4" />}
            color="bg-red-500"
          />
          <MetricsCard
            title="Sleep"
            value={latestSleep?.value.toFixed(1) || '0'}
            unit="hours"
            trend={sleepTrend.trend}
            trendValue={sleepTrend.value}
            icon={<Moon className="h-4 w-4" />}
            color="bg-purple-500"
          />
          <MetricsCard
            title="Calories"
            value={latestCalories?.value.toLocaleString() || '0'}
            unit="cal"
            trend={caloriesTrend.trend}
            trendValue={caloriesTrend.value}
            icon={<Zap className="h-4 w-4" />}
            color="bg-orange-500"
          />
          <MetricsCard
            title="Blood Pressure"
            value={latestBP?.value.toString() || '0'}
            unit="mmHg"
            icon={<Gauge className="h-4 w-4" />}
            color="bg-indigo-500"
          />
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <HealthChart
            title="Daily Steps"
            data={getChartData('steps')}
            color="#3b82f6"
            type="area"
            unit="steps"
          />
          <HealthChart
            title="Heart Rate"
            data={getChartData('heartRate')}
            color="#ef4444"
            type="line"
            unit="bpm"
          />
          <HealthChart
            title="Sleep Duration"
            data={getChartData('sleep')}
            color="#8b5cf6"
            type="area"
            unit="hours"
          />
          <HealthChart
            title="Calories Burned"
            data={getChartData('calories')}
            color="#f97316"
            type="line"
            unit="cal"
          />
        </div>

        {/* Recent Activities */}
        <div className="grid grid-cols-1 lg:grid-cols-1 gap-6">
          <ActivityList activities={userActivities} limit={15} />
        </div>
      </div>
    </div>
  );
}