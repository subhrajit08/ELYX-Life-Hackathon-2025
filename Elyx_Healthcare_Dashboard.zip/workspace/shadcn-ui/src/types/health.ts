export interface User {
  id: string;
  name: string;
  age: number;
  email: string;
  avatar?: string;
}

export interface Activity {
  id: string;
  userId: string;
  type: 'steps' | 'heartRate' | 'sleep' | 'exercise' | 'calories' | 'bloodPressure';
  value: number;
  unit: string;
  timestamp: string;
  notes?: string;
}

export interface HealthMetrics {
  steps: number;
  heartRate: number;
  sleep: number;
  calories: number;
  bloodPressure: {
    systolic: number;
    diastolic: number;
  };
}

export interface ChartData {
  date: string;
  value: number;
  label?: string;
}