import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FileText, Utensils, Calendar, Clock } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface TabSectionProps {
  patientName: string;
}

export function TabSection({ patientName }: TabSectionProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Patient Dashboard</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="reports" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="reports" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Your Reports
            </TabsTrigger>
            <TabsTrigger value="diet" className="flex items-center gap-2">
              <Utensils className="h-4 w-4" />
              Your Diet
            </TabsTrigger>
            <TabsTrigger value="appointments" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Future Appointments
            </TabsTrigger>
          </TabsList>

          <TabsContent value="reports" className="mt-4">
            <div className="text-center py-8 text-muted-foreground">
              <FileText className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <h3 className="text-lg font-medium mb-2">No Reports Available</h3>
              <p className="text-sm">There are no medical reports at the moment.</p>
              <p className="text-xs mt-2">Reports will appear here once they are generated.</p>
            </div>
          </TabsContent>

          <TabsContent value="diet" className="mt-4">
            <div className="space-y-4">
              <div className="text-center py-4">
                <Utensils className="h-8 w-8 mx-auto mb-3 text-green-500" />
                <h3 className="text-lg font-medium mb-4">Diet Plan for {patientName}</h3>
              </div>
              
              <div className="grid gap-4">
                <div className="border rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <h4 className="font-medium">Breakfast</h4>
                    <Badge variant="outline">7:00 AM</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Oatmeal with berries, Greek yogurt, green tea
                  </p>
                  <p className="text-xs text-green-600 mt-1">~350 calories</p>
                </div>

                <div className="border rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <h4 className="font-medium">Lunch</h4>
                    <Badge variant="outline">12:30 PM</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Grilled chicken salad with mixed vegetables
                  </p>
                  <p className="text-xs text-green-600 mt-1">~420 calories</p>
                </div>

                <div className="border rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <h4 className="font-medium">Dinner</h4>
                    <Badge variant="outline">7:00 PM</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Salmon with quinoa and steamed broccoli
                  </p>
                  <p className="text-xs text-green-600 mt-1">~480 calories</p>
                </div>

                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <h4 className="font-medium text-green-800 mb-2">Daily Targets</h4>
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <p className="font-medium text-green-700">Calories</p>
                      <p className="text-green-600">1,250 / 1,400</p>
                    </div>
                    <div>
                      <p className="font-medium text-green-700">Protein</p>
                      <p className="text-green-600">85g / 100g</p>
                    </div>
                    <div>
                      <p className="font-medium text-green-700">Water</p>
                      <p className="text-green-600">6 / 8 glasses</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="appointments" className="mt-4">
            <div className="text-center py-8 text-muted-foreground">
              <Calendar className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <h3 className="text-lg font-medium mb-2">No Upcoming Appointments</h3>
              <p className="text-sm">You don't have any scheduled appointments.</p>
              <p className="text-xs mt-2 flex items-center justify-center gap-1">
                <Clock className="h-3 w-3" />
                Check back later for new appointments.
              </p>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}