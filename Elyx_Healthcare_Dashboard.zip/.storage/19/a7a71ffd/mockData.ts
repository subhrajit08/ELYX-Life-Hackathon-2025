import { User, Activity } from '../types/health';

export const mockUsers: User[] = [
  {
    id: '1',
    name: 'Rohan Patel',
    age: 46,
    email: 'rohan.patel@elyxhealthcare.com',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face'
  }
];

const generateActivities = (userId: string): Activity[] => {
  const activities: Activity[] = [];
  
  // Generate data from Feb 2 to Oct 5, 2024
  const startDate = new Date('2024-02-02');
  const endDate = new Date('2024-10-05');
  const totalDays = Math.floor((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
  
  for (let i = 0; i <= totalDays; i++) {
    const date = new Date(startDate);
    date.setDate(date.getDate() + i);
    
    // Create jarring to smooth transition effect
    // Early months (Feb-May) have more volatile data, later months (Jun-Oct) are smoother
    const progressRatio = i / totalDays; // 0 to 1
    const volatilityFactor = Math.max(0.1, 1 - progressRatio * 1.2); // High volatility early, low later
    
    // Steps - jarring early, smooth later
    const baseSteps = 7000 + (progressRatio * 2000); // Gradual increase over time
    const stepsVariance = (Math.random() - 0.5) * 4000 * volatilityFactor;
    activities.push({
      id: `${userId}-steps-${i}`,
      userId,
      type: 'steps',
      value: Math.max(3000, Math.floor(baseSteps + stepsVariance)),
      unit: 'steps',
      timestamp: date.toISOString()
    });
    
    // Heart Rate - jarring early, smooth later
    const baseHR = 75 + (Math.sin(progressRatio * Math.PI) * 5); // Slight wave pattern
    const hrVariance = (Math.random() - 0.5) * 25 * volatilityFactor;
    activities.push({
      id: `${userId}-hr-${i}`,
      userId,
      type: 'heartRate',
      value: Math.max(55, Math.min(95, Math.floor(baseHR + hrVariance))),
      unit: 'bpm',
      timestamp: date.toISOString()
    });
    
    // Sleep - jarring early, smooth later
    const baseSleep = 7.2 + (progressRatio * 0.8); // Gradual improvement
    const sleepVariance = (Math.random() - 0.5) * 2.5 * volatilityFactor;
    activities.push({
      id: `${userId}-sleep-${i}`,
      userId,
      type: 'sleep',
      value: Math.max(5, Math.min(9.5, baseSleep + sleepVariance)),
      unit: 'hours',
      timestamp: date.toISOString()
    });
    
    // Calories - jarring early, smooth later
    const baseCalories = 2200 + (progressRatio * 300);
    const caloriesVariance = (Math.random() - 0.5) * 600 * volatilityFactor;
    activities.push({
      id: `${userId}-calories-${i}`,
      userId,
      type: 'calories',
      value: Math.max(1800, Math.floor(baseCalories + caloriesVariance)),
      unit: 'cal',
      timestamp: date.toISOString()
    });
    
    // Blood Pressure (every 3 days) - jarring early, smooth later
    if (i % 3 === 0) {
      const baseBP = 125 - (progressRatio * 10); // Gradual improvement
      const bpVariance = (Math.random() - 0.5) * 20 * volatilityFactor;
      activities.push({
        id: `${userId}-bp-sys-${i}`,
        userId,
        type: 'bloodPressure',
        value: Math.max(110, Math.min(140, Math.floor(baseBP + bpVariance))),
        unit: 'mmHg sys',
        timestamp: date.toISOString()
      });
    }
  }
  
  return activities;
};

export const mockActivities: Activity[] = mockUsers.flatMap(user => 
  generateActivities(user.id)
);