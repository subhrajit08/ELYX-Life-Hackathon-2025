import { useState, useMemo } from 'react';
import { UserSelector } from '../components/UserSelector';
import { MetricsCard } from '../components/MetricsCard';
import { HealthChart } from '../components/HealthChart';
import { ActivityList } from '../components/ActivityList';
import { ChatSection } from '../components/ChatSection';
import { TabSection } from '../components/TabSection';
import { mockUsers, mockActivities } from '../data/mockData';
import { Activity, ChartData } from '../types/health';
import { Heart, Footprints, Moon, Zap, Gauge, User } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

export default function Dashboard() {
  const [selectedUserId, setSelectedUserId] = useState<string>(mockUsers[0].id);

  const selectedUser = useMemo(() => 
    mockUsers.find(u => u.id === selectedUserId), 
    [selectedUserId]
  );

  const userActivities = useMemo(() => 
    mockActivities.filter(a => a.userId === selectedUserId), 
    [selectedUserId]
  );

  const getLatestMetric = (type: Activity['type']) => {
    const activities = userActivities
      .filter(a => a.type === type)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    
    return activities[0];
  };

  const getChartData = (type: Activity['type'], days: number = 30): ChartData[] => {
    const now = new Date();
    const cutoffDate = new Date(now.getTime() - (days * 24 * 60 * 60 * 1000));
    
    return userActivities
      .filter(a => a.type === type && new Date(a.timestamp) >= cutoffDate)
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
      .map(a => ({
        date: a.timestamp,
        value: Math.round(a.value * 100) / 100
      }));
  };

  const getAllChartData = (type: Activity['type']): ChartData[] => {
    return userActivities
      .filter(a => a.type === type)
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
      .map(a => ({
        date: a.timestamp,
        value: Math.round(a.value * 100) / 100
      }));
  };

  const getTrend = (type: Activity['type']) => {
    const data = getChartData(type);
    if (data.length < 2) return { trend: 'stable' as const, value: '0%' };
    
    const latest = data[data.length - 1].value;
    const previous = data[data.length - 2].value;
    const change = ((latest - previous) / previous) * 100;
    
    return {
      trend: change > 5 ? 'up' as const : change < -5 ? 'down' as const : 'stable' as const,
      value: `${Math.abs(Math.round(change))}%`
    };
  };

  const latestSteps = getLatestMetric('steps');
  const latestHeartRate = getLatestMetric('heartRate');
  const latestSleep = getLatestMetric('sleep');
  const latestCalories = getLatestMetric('calories');
  const latestBP = getLatestMetric('bloodPressure');

  const stepsTrend = getTrend('steps');
  const heartRateTrend = getTrend('heartRate');
  const sleepTrend = getTrend('sleep');
  const caloriesTrend = getTrend('calories');

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Elyx Healthcare</h1>
            <p className="text-muted-foreground">Personal Dashboard for Rohan Patel</p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Avatar className="h-8 w-8">
                <AvatarImage src={selectedUser?.avatar} />
                <AvatarFallback>RP</AvatarFallback>
              </Avatar>
              <span className="text-sm font-medium">Rohan Patel</span>
            </div>
            <button 
              onClick={() => {
                if (window.confirm('Are you sure you want to log out?')) {
                  window.location.href = '/';
                }
              }}
              className="px-4 py-2 text-sm bg-red-500 hover:bg-red-600 text-white rounded-md transition-colors"
            >
              Logout
            </button>
          </div>
        </div>

        {/* Personal Info and Health Summary */}
        {selectedUser && (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Personal Info */}
            <div className="lg:col-span-1 space-y-4">
              <Card className="hover:shadow-lg transition-shadow duration-200">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-3">
                    <User className="h-5 w-5" />
                    <span>Personal Information</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center space-x-4">
                    <Avatar className="h-16 w-16">
                      <AvatarImage src={selectedUser.avatar} />
                      <AvatarFallback className="text-lg">
                        {selectedUser.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="text-xl font-semibold">{selectedUser.name}</h3>
                      <p className="text-muted-foreground">Age: {selectedUser.age}</p>
                      <p className="text-muted-foreground">{selectedUser.email}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Health Journey Summary */}
              <Card className="hover:shadow-lg transition-shadow duration-200">
                <CardHeader>
                  <CardTitle>Health Journey</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="space-y-2">
                      <div className="text-sm font-medium">Period: Feb 2 - Oct 5, 2024</div>
                      <div className="text-xs text-muted-foreground">
                        Your health journey shows significant improvement over time, with initial fluctuations stabilizing into consistent healthy patterns.
                      </div>
                      <div className="mt-3 p-2 bg-blue-50 rounded-md">
                        <div className="text-xs font-medium text-blue-700">Journey Highlights:</div>
                        <ul className="text-xs text-blue-600 mt-1 space-y-1">
                          <li>• Feb-May: Adjustment period with variable metrics</li>
                          <li>• Jun-Oct: Steady improvement and consistency</li>
                          <li>• Overall trend: Positive health progression</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Tab Section */}
            <div className="lg:col-span-3">
              <TabSection patientName={selectedUser.name} />
            </div>
          </div>
        )}

        {/* Your Activity Section */}
        {selectedUser && (
          <Card className="hover:shadow-lg transition-shadow duration-200">
            <CardHeader>
              <CardTitle className="text-xl">Your Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                <MetricsCard
                  title="Daily Steps"
                  value={latestSteps?.value.toLocaleString() || '0'}
                  unit="steps"
                  trend={stepsTrend.trend}
                  trendValue={stepsTrend.value}
                  icon={<Footprints className="h-4 w-4" />}
                  color="bg-blue-500"
                />
                <MetricsCard
                  title="Heart Rate"
                  value={latestHeartRate?.value.toString() || '0'}
                  unit="bpm"
                  trend={heartRateTrend.trend}
                  trendValue={heartRateTrend.value}
                  icon={<Heart className="h-4 w-4" />}
                  color="bg-red-500"
                />
                <MetricsCard
                  title="Sleep"
                  value={latestSleep?.value.toFixed(1) || '0'}
                  unit="hours"
                  trend={sleepTrend.trend}
                  trendValue={sleepTrend.value}
                  icon={<Moon className="h-4 w-4" />}
                  color="bg-purple-500"
                />
                <MetricsCard
                  title="Calories"
                  value={latestCalories?.value.toLocaleString() || '0'}
                  unit="cal"
                  trend={caloriesTrend.trend}
                  trendValue={caloriesTrend.value}
                  icon={<Zap className="h-4 w-4" />}
                  color="bg-orange-500"
                />
                <MetricsCard
                  title="Blood Pressure"
                  value={latestBP?.value.toString() || '0'}
                  unit="mmHg"
                  icon={<Gauge className="h-4 w-4" />}
                  color="bg-indigo-500"
                />
              </div>
            </CardContent>
          </Card>
        )}

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <HealthChart
            title="Daily Steps (Feb 2 - Oct 5, 2024)"
            data={getAllChartData('steps')}
            color="#3b82f6"
            type="area"
            unit="steps"
          />
          <HealthChart
            title="Heart Rate (Feb 2 - Oct 5, 2024)"
            data={getAllChartData('heartRate')}
            color="#ef4444"
            type="line"
            unit="bpm"
          />
          <HealthChart
            title="Sleep Duration (Feb 2 - Oct 5, 2024)"
            data={getAllChartData('sleep')}
            color="#8b5cf6"
            type="area"
            unit="hours"
          />
          <HealthChart
            title="Calories Burned (Feb 2 - Oct 5, 2024)"
            data={getAllChartData('calories')}
            color="#f97316"
            type="line"
            unit="cal"
          />
        </div>

        {/* Recent Activities */}
        <div className="grid grid-cols-1 lg:grid-cols-1 gap-6">
          <ActivityList activities={userActivities} limit={15} />
        </div>
      </div>
    </div>
  );
}