import ChatLogViewer from '@/components/ChatLogViewer';

export default function Index() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      <ChatLogViewer />
    </div>
  );
}
