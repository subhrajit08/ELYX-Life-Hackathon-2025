import React, { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ArrowUpDown, ArrowUp, ArrowDown, Search, Filter, MessageCircle } from 'lucide-react';

interface Message {
  id: string;
  timestamp: string;
  sender: string;
  text: string;
  pillar: string;
  related_ids: string[];
}

const ChatLogViewer: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [filterPillar, setFilterPillar] = useState<string>('');
  const [filterSender, setFilterSender] = useState<string>('all');
  const [searchText, setSearchText] = useState('');

  useEffect(() => {
    const loadMessages = async () => {
      try {
        const response = await fetch('/data/messagesfinal.json');
        const data: Message[] = await response.json();
        setMessages(data);
      } catch (error) {
        console.error('Error loading messages:', error);
      } finally {
        setLoading(false);
      }
    };

    loadMessages();
  }, []);

  const uniquePillars = useMemo(() => {
    const pillars = [...new Set(messages.map(msg => msg.pillar))];
    return pillars.sort();
  }, [messages]);

  const uniqueSenders = useMemo(() => {
    const senders = [...new Set(messages.map(msg => msg.sender))];
    return senders.sort();
  }, [messages]);

  const filteredAndSortedMessages = useMemo(() => {
    const filtered = messages.filter(msg => {
      const pillarMatch = filterPillar === 'all' || msg.pillar === filterPillar;
      const senderMatch = filterSender === 'all' || msg.sender === filterSender;
      const textMatch = searchText === '' || 
        msg.text.toLowerCase().includes(searchText.toLowerCase()) ||
        msg.sender.toLowerCase().includes(searchText.toLowerCase());
      
      return pillarMatch && senderMatch && textMatch;
    });

    return filtered.sort((a, b) => {
      const dateA = new Date(a.timestamp).getTime();
      const dateB = new Date(b.timestamp).getTime();
      return sortOrder === 'asc' ? dateA - dateB : dateB - dateA;
    });
  }, [messages, sortOrder, filterPillar, filterSender, searchText]);

  const toggleSortOrder = () => {
    setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc');
  };

  const clearFilters = () => {
    setFilterPillar('all');
    setFilterSender('all');
    setSearchText('');
  };

  const getPillarColor = (pillar: string) => {
    const colors: { [key: string]: string } = {
      'Conversation': 'bg-blue-100 text-blue-800',
      'Logistics': 'bg-green-100 text-green-800',
      'Medical': 'bg-red-100 text-red-800',
      'Performance': 'bg-purple-100 text-purple-800',
      'Financial': 'bg-yellow-100 text-yellow-800',
      'Technology': 'bg-indigo-100 text-indigo-800',
    };
    return colors[pillar] || 'bg-gray-100 text-gray-800';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
          <p className="mt-4 text-lg">Loading chat logs...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageCircle className="h-6 w-6" />
            Chat Log Viewer
            <Badge variant="secondary" className="ml-2">
              {filteredAndSortedMessages.length} messages
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4 mb-4">
            {/* Search */}
            <div className="flex-1 min-w-64">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search messages or senders..."
                  value={searchText}
                  onChange={(e) => setSearchText(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            {/* Sort Order */}
            <Button
              variant="outline"
              onClick={toggleSortOrder}
              className="flex items-center gap-2"
            >
              {sortOrder === 'asc' ? (
                <>
                  <ArrowUp className="h-4 w-4" />
                  Old to New
                </>
              ) : (
                <>
                  <ArrowDown className="h-4 w-4" />
                  New to Old
                </>
              )}
            </Button>

            {/* Pillar Filter */}
            <Select value={filterPillar} onValueChange={setFilterPillar}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter by Pillar" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Pillars</SelectItem>
                {uniquePillars.map(pillar => (
                  <SelectItem key={pillar} value={pillar}>{pillar}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Sender Filter */}
            <Select value={filterSender} onValueChange={setFilterSender}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter by Sender" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Senders</SelectItem>
                {uniqueSenders.map(sender => (
                  <SelectItem key={sender} value={sender}>{sender}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Clear Filters */}
            <Button variant="outline" onClick={clearFilters}>
              <Filter className="h-4 w-4 mr-2" />
              Clear Filters
            </Button>
          </div>
        </CardContent>
      </Card>

      <ScrollArea className="h-[calc(100vh-280px)]">
        <div className="space-y-4">
          {filteredAndSortedMessages.map((message) => (
            <Card key={message.id} className="transition-all hover:shadow-md">
              <CardContent className="p-4">
                <div className="flex flex-col space-y-3">
                  {/* Header */}
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-3">
                      <Badge variant="outline" className="font-medium">
                        {message.sender}
                      </Badge>
                      <Badge className={getPillarColor(message.pillar)}>
                        {message.pillar}
                      </Badge>
                      <span className="text-sm text-muted-foreground">
                        {message.timestamp}
                      </span>
                    </div>
                    <Badge variant="secondary" className="text-xs">
                      ID: {message.id}
                    </Badge>
                  </div>
                  
                  {/* Message Text */}
                  <div className="text-gray-800 leading-relaxed">
                    {message.text}
                  </div>

                  {/* Related IDs */}
                  {message.related_ids && message.related_ids.length > 0 && (
                    <div className="text-xs text-muted-foreground">
                      <span className="font-medium">Related: </span>
                      {message.related_ids.join(', ')}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
          
          {filteredAndSortedMessages.length === 0 && (
            <Card>
              <CardContent className="p-8 text-center">
                <MessageCircle className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-lg font-medium text-muted-foreground">No messages found</p>
                <p className="text-sm text-muted-foreground mt-2">
                  Try adjusting your search or filter criteria
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </ScrollArea>
    </div>
  );
};

export default ChatLogViewer;