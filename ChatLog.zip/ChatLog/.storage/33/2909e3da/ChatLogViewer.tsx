import React, { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowUpDown, ArrowUp, ArrowDown, Search, Filter, MessageCircle, BarChart3, Users, Calendar, TrendingUp } from 'lucide-react';

interface Message {
  id: string;
  timestamp: string;
  sender: string;
  text: string;
  pillar: string;
  related_ids: string[];
}

const ChatLogViewer: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [filterPillar, setFilterPillar] = useState<string>('');
  const [filterSender, setFilterSender] = useState<string>('all');
  const [searchText, setSearchText] = useState('');

  useEffect(() => {
    const loadMessages = async () => {
      try {
        const response = await fetch('/data/messagesfinal.json');
        const data: Message[] = await response.json();
        setMessages(data);
      } catch (error) {
        console.error('Error loading messages:', error);
      } finally {
        setLoading(false);
      }
    };

    loadMessages();
  }, []);

  const uniquePillars = useMemo(() => {
    const pillars = [...new Set(messages.map(msg => msg.pillar))];
    return pillars.sort();
  }, [messages]);

  const uniqueSenders = useMemo(() => {
    const senders = [...new Set(messages.map(msg => msg.sender))];
    return senders.sort();
  }, [messages]);

  const filteredAndSortedMessages = useMemo(() => {
    const filtered = messages.filter(msg => {
      const pillarMatch = filterPillar === '' || msg.pillar === filterPillar;
      const senderMatch = filterSender === 'all' || msg.sender === filterSender;
      const textMatch = searchText === '' || 
        msg.text.toLowerCase().includes(searchText.toLowerCase()) ||
        msg.sender.toLowerCase().includes(searchText.toLowerCase());
      
      return pillarMatch && senderMatch && textMatch;
    });

    return filtered.sort((a, b) => {
      const dateA = new Date(a.timestamp).getTime();
      const dateB = new Date(b.timestamp).getTime();
      return sortOrder === 'asc' ? dateA - dateB : dateB - dateA;
    });
  }, [messages, sortOrder, filterPillar, filterSender, searchText]);

  const toggleSortOrder = () => {
    setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc');
  };

  const clearFilters = () => {
    setFilterPillar('');
    setFilterSender('all');
    setSearchText('');
  };

  const getSenderColor = (sender: string) => {
    const colors: { [key: string]: string } = {
      'Ruby': 'bg-pink-100 text-pink-800 border-pink-200',
      'Rohan': 'bg-blue-100 text-blue-800 border-blue-200',
      'Sarah': 'bg-green-100 text-green-800 border-green-200',
      'Alex': 'bg-purple-100 text-purple-800 border-purple-200',
      'Mike': 'bg-orange-100 text-orange-800 border-orange-200',
      'Emma': 'bg-indigo-100 text-indigo-800 border-indigo-200',
      'David': 'bg-yellow-100 text-yellow-800 border-yellow-200',
      'Lisa': 'bg-teal-100 text-teal-800 border-teal-200',
    };
    
    // Generate a consistent color for unknown senders
    if (!colors[sender]) {
      const hash = sender.split('').reduce((a, b) => {
        a = ((a << 5) - a) + b.charCodeAt(0);
        return a & a;
      }, 0);
      const colorOptions = [
        'bg-red-100 text-red-800 border-red-200',
        'bg-cyan-100 text-cyan-800 border-cyan-200',
        'bg-lime-100 text-lime-800 border-lime-200',
        'bg-rose-100 text-rose-800 border-rose-200',
        'bg-amber-100 text-amber-800 border-amber-200',
        'bg-emerald-100 text-emerald-800 border-emerald-200',
        'bg-violet-100 text-violet-800 border-violet-200',
        'bg-sky-100 text-sky-800 border-sky-200',
      ];
      return colorOptions[Math.abs(hash) % colorOptions.length];
    }
    
    return colors[sender];
  };

  const getPillarColor = (pillar: string) => {
    const colors: { [key: string]: string } = {
      'Conversation': 'bg-blue-100 text-blue-800',
      'Logistics': 'bg-green-100 text-green-800',
      'Medical': 'bg-red-100 text-red-800',
      'Performance': 'bg-purple-100 text-purple-800',
      'Financial': 'bg-yellow-100 text-yellow-800',
      'Technology': 'bg-indigo-100 text-indigo-800',
    };
    return colors[pillar] || 'bg-gray-100 text-gray-800';
  };

  // Analytics calculations
  const analytics = useMemo(() => {
    const totalMessages = messages.length;
    const senderStats = messages.reduce((acc, msg) => {
      acc[msg.sender] = (acc[msg.sender] || 0) + 1;
      return acc;
    }, {} as { [key: string]: number });

    const pillarStats = messages.reduce((acc, msg) => {
      acc[msg.pillar] = (acc[msg.pillar] || 0) + 1;
      return acc;
    }, {} as { [key: string]: number });

    const dateStats = messages.reduce((acc, msg) => {
      const date = msg.timestamp.split(' ')[0]; // Get just the date part
      acc[date] = (acc[date] || 0) + 1;
      return acc;
    }, {} as { [key: string]: number });

    const avgMessagesPerDay = Object.keys(dateStats).length > 0 
      ? totalMessages / Object.keys(dateStats).length 
      : 0;

    return {
      totalMessages,
      senderStats,
      pillarStats,
      dateStats,
      avgMessagesPerDay: Math.round(avgMessagesPerDay * 100) / 100,
      topSender: Object.entries(senderStats).sort(([,a], [,b]) => b - a)[0] || ['N/A', 0],
      topPillar: Object.entries(pillarStats).sort(([,a], [,b]) => b - a)[0] || ['N/A', 0],
    };
  }, [messages]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
          <p className="mt-4 text-lg">Loading chat logs...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <Tabs defaultValue="messages" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="messages" className="flex items-center gap-2">
            <MessageCircle className="h-4 w-4" />
            Chat Messages
          </TabsTrigger>
          <TabsTrigger value="analytics" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            Analytics
          </TabsTrigger>
        </TabsList>

        <TabsContent value="messages">
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageCircle className="h-6 w-6" />
                Chat Log Viewer
                <Badge variant="secondary" className="ml-2">
                  {filteredAndSortedMessages.length} messages
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-4 mb-4">
                {/* Search */}
                <div className="flex-1 min-w-64">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      placeholder="Search messages or senders..."
                      value={searchText}
                      onChange={(e) => setSearchText(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                {/* Sort Order */}
                <Button
                  variant="outline"
                  onClick={toggleSortOrder}
                  className="flex items-center gap-2"
                >
                  {sortOrder === 'asc' ? (
                    <>
                      <ArrowUp className="h-4 w-4" />
                      Old to New
                    </>
                  ) : (
                    <>
                      <ArrowDown className="h-4 w-4" />
                      New to Old
                    </>
                  )}
                </Button>

                {/* Pillar Filter */}
                <Select value={filterPillar} onValueChange={setFilterPillar}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Select a Pillar" />
                  </SelectTrigger>
                  <SelectContent>
                    {uniquePillars.map(pillar => (
                      <SelectItem key={pillar} value={pillar}>{pillar}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {/* Sender Filter */}
                <Select value={filterSender} onValueChange={setFilterSender}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Filter by Sender" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Senders</SelectItem>
                    {uniqueSenders.map(sender => (
                      <SelectItem key={sender} value={sender}>{sender}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {/* Clear Filters */}
                <Button variant="outline" onClick={clearFilters}>
                  <Filter className="h-4 w-4 mr-2" />
                  Clear Filters
                </Button>
              </div>
            </CardContent>
          </Card>

          <ScrollArea className="h-[calc(100vh-280px)]">
            <div className="space-y-4">
              {filteredAndSortedMessages.map((message) => (
                <Card key={message.id} className="transition-all hover:shadow-md">
                  <CardContent className="p-4">
                    <div className="flex flex-col space-y-3">
                      {/* Header */}
                      <div className="flex items-center justify-between flex-wrap gap-2">
                        <div className="flex items-center gap-3">
                          <Badge className={getSenderColor(message.sender)}>
                            {message.sender}
                          </Badge>
                          <span className="text-sm text-muted-foreground">
                            {message.timestamp}
                          </span>
                        </div>
                      </div>
                      
                      {/* Message Text */}
                      <div className="text-gray-800 leading-relaxed">
                        {message.text}
                      </div>

                      {/* Related IDs */}
                      {message.related_ids && message.related_ids.length > 0 && (
                        <div className="text-xs text-muted-foreground">
                          <span className="font-medium">Related: </span>
                          {message.related_ids.join(', ')}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
              
              {filteredAndSortedMessages.length === 0 && (
                <Card>
                  <CardContent className="p-8 text-center">
                    <MessageCircle className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <p className="text-lg font-medium text-muted-foreground">
                      {filterPillar === '' ? 'Please select a pillar to view messages' : 'No messages found'}
                    </p>
                    <p className="text-sm text-muted-foreground mt-2">
                      {filterPillar === '' 
                        ? 'Choose a pillar from the dropdown above to display messages'
                        : 'Try adjusting your search or filter criteria'
                      }
                    </p>
                  </CardContent>
                </Card>
              )}
            </div>
          </ScrollArea>
        </TabsContent>

        <TabsContent value="analytics">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 mb-6">
            {/* Overview Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageCircle className="h-5 w-5" />
                  Overview
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Total Messages:</span>
                    <span className="font-medium">{analytics.totalMessages}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Avg/Day:</span>
                    <span className="font-medium">{analytics.avgMessagesPerDay}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Active Days:</span>
                    <span className="font-medium">{Object.keys(analytics.dateStats).length}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Top Sender */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Most Active
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <Badge className={getSenderColor(analytics.topSender[0])}>
                        {analytics.topSender[0]}
                      </Badge>
                      <span className="font-medium">{analytics.topSender[1]} messages</span>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Top Pillar:</span>
                      <Badge className={getPillarColor(analytics.topPillar[0])}>
                        {analytics.topPillar[0]}
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Sender Distribution */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Senders
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-32 overflow-y-auto">
                  {Object.entries(analytics.senderStats)
                    .sort(([,a], [,b]) => b - a)
                    .map(([sender, count]) => (
                      <div key={sender} className="flex justify-between items-center">
                        <Badge variant="outline" className={getSenderColor(sender)}>
                          {sender}
                        </Badge>
                        <span className="text-sm font-medium">{count}</span>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>

            {/* Pillar Distribution */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Filter className="h-5 w-5" />
                  Pillars
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {Object.entries(analytics.pillarStats)
                    .sort(([,a], [,b]) => b - a)
                    .map(([pillar, count]) => (
                      <div key={pillar} className="flex justify-between items-center">
                        <Badge className={getPillarColor(pillar)}>
                          {pillar}
                        </Badge>
                        <span className="text-sm font-medium">{count}</span>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  Daily Activity
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-32 overflow-y-auto">
                  {Object.entries(analytics.dateStats)
                    .sort(([a], [b]) => new Date(b).getTime() - new Date(a).getTime())
                    .slice(0, 10)
                    .map(([date, count]) => (
                      <div key={date} className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">{date}</span>
                        <Badge variant="secondary">{count} messages</Badge>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ChatLogViewer;