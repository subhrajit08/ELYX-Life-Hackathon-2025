import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Activity } from '../types/health';
import { Activity as ActivityIcon, Heart, Moon, Zap, Footprints, Gauge } from 'lucide-react';

interface ActivityListProps {
  activities: Activity[];
  limit?: number;
}

export function ActivityList({ activities, limit = 10 }: ActivityListProps) {
  const getActivityIcon = (type: Activity['type']) => {
    const iconMap = {
      steps: <Footprints className="h-4 w-4" />,
      heartRate: <Heart className="h-4 w-4" />,
      sleep: <Moon className="h-4 w-4" />,
      exercise: <ActivityIcon className="h-4 w-4" />,
      calories: <Zap className="h-4 w-4" />,
      bloodPressure: <Gauge className="h-4 w-4" />,
    };
    return iconMap[type] || <ActivityIcon className="h-4 w-4" />;
  };

  const getActivityColor = (type: Activity['type']) => {
    const colorMap = {
      steps: 'bg-blue-500',
      heartRate: 'bg-red-500',
      sleep: 'bg-purple-500',
      exercise: 'bg-green-500',
      calories: 'bg-orange-500',
      bloodPressure: 'bg-indigo-500',
    };
    return colorMap[type] || 'bg-gray-500';
  };

  const formatActivityType = (type: Activity['type']) => {
    const typeMap = {
      steps: 'Steps',
      heartRate: 'Heart Rate',
      sleep: 'Sleep',
      exercise: 'Exercise',
      calories: 'Calories',
      bloodPressure: 'Blood Pressure',
    };
    return typeMap[type] || type;
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diffInHours = Math.abs(now.getTime() - date.getTime()) / (1000 * 60 * 60);
    
    if (diffInHours < 24) {
      return date.toLocaleTimeString('en-US', { 
        hour: 'numeric', 
        minute: '2-digit',
        hour12: true 
      });
    }
    
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric' 
    });
  };

  const sortedActivities = activities
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    .slice(0, limit);

  return (
    <Card className="hover:shadow-lg transition-shadow duration-200">
      <CardHeader>
        <CardTitle className="text-lg">Recent Activities</CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[400px]">
          <div className="space-y-3">
            {sortedActivities.map((activity) => (
              <div
                key={activity.id}
                className="flex items-center space-x-3 p-3 rounded-lg border border-gray-100 hover:bg-gray-50 transition-colors"
              >
                <div className={`${getActivityColor(activity.type)} p-2 rounded-md text-white`}>
                  {getActivityIcon(activity.type)}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <p className="font-medium">{formatActivityType(activity.type)}</p>
                    <Badge variant="secondary" className="text-xs">
                      {formatDate(activity.timestamp)}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {Math.round(activity.value * 100) / 100} {activity.unit}
                  </p>
                  {activity.notes && (
                    <p className="text-xs text-muted-foreground mt-1">
                      {activity.notes}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}