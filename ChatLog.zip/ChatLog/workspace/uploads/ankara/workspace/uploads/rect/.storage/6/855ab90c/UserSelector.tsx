import { User } from '../types/health';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

interface UserSelectorProps {
  users: User[];
  selectedUserId?: string;
  onUserSelect: (userId: string) => void;
}

export function UserSelector({ users, selectedUserId, onUserSelect }: UserSelectorProps) {
  const selectedUser = users.find(u => u.id === selectedUserId);
  
  return (
    <div className="flex flex-col space-y-2">
      <label className="text-sm font-medium">Select Patient</label>
      <Select value={selectedUserId} onValueChange={onUserSelect}>
        <SelectTrigger className="w-full">
          <SelectValue placeholder="Choose a patient">
            {selectedUser && (
              <div className="flex items-center space-x-2">
                <Avatar className="h-6 w-6">
                  <AvatarImage src={selectedUser.avatar} />
                  <AvatarFallback>
                    {selectedUser.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <span>{selectedUser.name}</span>
              </div>
            )}
          </SelectValue>
        </SelectTrigger>
        <SelectContent>
          {users.map((user) => (
            <SelectItem key={user.id} value={user.id}>
              <div className="flex items-center space-x-2">
                <Avatar className="h-6 w-6">
                  <AvatarImage src={user.avatar} />
                  <AvatarFallback>
                    {user.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div className="flex flex-col">
                  <span>{user.name}</span>
                  <span className="text-xs text-muted-foreground">{user.email}</span>
                </div>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}