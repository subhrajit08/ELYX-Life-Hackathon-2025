import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MessageCircle, Clock, User, Bot } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import messagesData from '@/data/messages.json';

interface Message {
  id: string;
  timestamp: string;
  sender: string;
  text: string;
  pillar: string;
  related_ids: string[];
}

interface ChatSectionProps {
  patientName: string;
}

export function ChatSection({ patientName }: ChatSectionProps) {
  const messages = messagesData as Message[];
  
  // Get the most recent 5 messages for display
  const recentMessages = messages
    .slice(-5)
    .reverse()
    .map(msg => ({
      id: msg.id,
      time: new Date(msg.timestamp).toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }),
      message: msg.text,
      sender: msg.sender,
      pillar: msg.pillar
    }));

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between text-lg">
          <div className="flex items-center space-x-2">
            <MessageCircle className="h-5 w-5 text-blue-500" />
            <span>Chat Log</span>
          </div>
          <Badge variant="secondary" className="text-xs">
            {recentMessages.length} messages
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="space-y-2">
          {recentMessages.map((msg, index) => (
            <div key={index} className="flex items-start space-x-2 text-sm">
              <Clock className="h-3 w-3 text-muted-foreground mt-1 flex-shrink-0" />
              <div className="flex-1">
                <p className="text-xs text-muted-foreground">{msg.time}</p>
                <p className="text-sm">{msg.message}</p>
              </div>
            </div>
          ))}
        </div>
        <Button 
          variant="outline" 
          size="sm" 
          className="w-full mt-3 hover:bg-blue-50 hover:border-blue-300"
        >
          <MessageCircle className="h-4 w-4 mr-2" />
          Open Chat with {patientName}
        </Button>
      </CardContent>
    </Card>
  );
}