import { User, Activity } from '../types/health';

export const mockUsers: User[] = [
  {
    id: '1',
    name: 'John Smith',
    age: 32,
    email: 'john.smith@email.com',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face'
  },
  {
    id: '2',
    name: 'Sarah Johnson',
    age: 28,
    email: 'sarah.johnson@email.com',
    avatar: '/images/portrait.jpg'
  },
  {
    id: '3',
    name: 'Mike Davis',
    age: 45,
    email: 'mike.davis@email.com',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face'
  },
  {
    id: '4',
    name: 'Emily Chen',
    age: 35,
    email: 'emily.chen@email.com',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face'
  }
];

const generateActivities = (userId: string): Activity[] => {
  const activities: Activity[] = [];
  const now = new Date();
  
  // Generate 8 months of data (approximately 240 days)
  for (let i = 240; i >= 0; i--) {
    const date = new Date(now);
    date.setDate(date.getDate() - i);
    
    // Steps
    activities.push({
      id: `${userId}-steps-${i}`,
      userId,
      type: 'steps',
      value: Math.floor(Math.random() * 5000) + 5000,
      unit: 'steps',
      timestamp: date.toISOString()
    });
    
    // Heart Rate
    activities.push({
      id: `${userId}-hr-${i}`,
      userId,
      type: 'heartRate',
      value: Math.floor(Math.random() * 40) + 60,
      unit: 'bpm',
      timestamp: date.toISOString()
    });
    
    // Sleep
    activities.push({
      id: `${userId}-sleep-${i}`,
      userId,
      type: 'sleep',
      value: Math.random() * 3 + 6,
      unit: 'hours',
      timestamp: date.toISOString()
    });
    
    // Calories
    activities.push({
      id: `${userId}-calories-${i}`,
      userId,
      type: 'calories',
      value: Math.floor(Math.random() * 800) + 1500,
      unit: 'cal',
      timestamp: date.toISOString()
    });
    
    // Blood Pressure (every 3 days)
    if (i % 3 === 0) {
      activities.push({
        id: `${userId}-bp-sys-${i}`,
        userId,
        type: 'bloodPressure',
        value: Math.floor(Math.random() * 30) + 110,
        unit: 'mmHg sys',
        timestamp: date.toISOString()
      });
    }
  }
  
  return activities;
};

export const mockActivities: Activity[] = mockUsers.flatMap(user => 
  generateActivities(user.id)
);