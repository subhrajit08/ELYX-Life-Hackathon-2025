import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MessageCircle, Clock, User, Bot } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import messagesData from '@/data/messages.json';

interface Message {
  id: string;
  timestamp: string;
  sender: string;
  text: string;
  pillar: string;
  related_ids: string[];
}

interface ChatSectionProps {
  patientName: string;
}

export function ChatSection({ patientName }: ChatSectionProps) {
  const messages = messagesData as Message[];
  
  // Get the most recent 5 messages for display
  const recentMessages = messages
    .slice(-5)
    .reverse()
    .map(msg => ({
      id: msg.id,
      time: new Date(msg.timestamp).toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }),
      message: msg.text,
      sender: msg.sender,
      pillar: msg.pillar
    }));

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between text-lg">
          <div className="flex items-center space-x-2">
            <MessageCircle className="h-5 w-5 text-blue-500" />
            <span>Chat Log</span>
          </div>
          <Badge variant="secondary" className="text-xs">
            {messages.length} messages
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="space-y-3">
          {recentMessages.map((msg) => (
            <div key={msg.id} className="flex items-start space-x-3 text-sm border-l-2 border-l-blue-100 pl-3 py-2">
              <div className="flex-shrink-0 mt-1">
                {msg.sender === 'Ruby' ? (
                  <Bot className="h-4 w-4 text-blue-500" />
                ) : (
                  <User className="h-4 w-4 text-green-500" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-xs font-medium text-muted-foreground">
                    {msg.sender}
                  </p>
                  <div className="flex items-center space-x-2">
                    <Badge 
                      variant="outline" 
                      className="text-xs px-1.5 py-0.5"
                    >
                      {msg.pillar}
                    </Badge>
                    <p className="text-xs text-muted-foreground flex items-center">
                      <Clock className="h-3 w-3 mr-1" />
                      {msg.time}
                    </p>
                  </div>
                </div>
                <p className="text-sm text-gray-700 leading-relaxed">
                  {msg.message}
                </p>
              </div>
            </div>
          ))}
        </div>
        <Button 
          variant="outline" 
          size="sm" 
          className="w-full mt-3 hover:bg-blue-50 hover:border-blue-300"
        >
          <MessageCircle className="h-4 w-4 mr-2" />
          Open Chat with {patientName}
        </Button>
      </CardContent>
    </Card>
  );
}